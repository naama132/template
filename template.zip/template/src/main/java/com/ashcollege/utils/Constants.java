package com.ashcollege.utils;


public class Constants {
    public static final String DB_USERNAME = "root";
    public static final String DB_PASSWORD = "1234";
}
